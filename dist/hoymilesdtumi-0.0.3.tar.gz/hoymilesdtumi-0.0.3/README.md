# HoymilesDtuMi
## Hoymiles DTU-MI data wrapper for python.
### Retrieving pv data from DTU.

1. Example
```
import hoymilesdtumi

json = hoymilesdtumi.dtu_http_request('192.168.0.109')
print(json)
```
